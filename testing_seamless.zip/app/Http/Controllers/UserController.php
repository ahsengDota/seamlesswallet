<?php

namespace App\Http\Controllers;
use DB;
use Log;

use Illuminate\Http\Request;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function userList()
    {
        $db = DB::table("users")->get();

        $userArr = array();

        foreach($db as $user)
        {
            $array = array(
                'name' => $user->name,
                'email' => $user->email,
                'balance' => number_format($user->balance,2),
                'phone_number' => '',
                'status' => 'Active',
            );

            array_push($userArr,$array);
        }

        return view('user')->with('userArr',$userArr);
    }

    public function register(Request $Request)
    {
        try
        {
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_PORT => "51528",
                CURLOPT_URL => "http://localhost:51528/api/user/Register",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => "{\n  \"APIPassword\": \"f1bf4faf87fb64b02f3354c49159e51e\", \n  \"AgentAccount\": \"2bc00000\",\n  \"NickName\": \"ggggg\",\n  \"Currency\": \"MYR\",\n  \"MemberAccount\": \"ggggg\"\n}",
                CURLOPT_HTTPHEADER => array(
                    "Accept: */*",
                    "Cache-Control: no-cache",
                    "Connection: keep-alive",
                    "Content-Length: 158",
                    "Content-Type: application/json",
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err)
            {
                echo "cURL Error #:" . $err;
            }
            else
            {
                echo $response;
            }
        }
        catch(\Exception $ex)
        {
            return $ex;
        }
    }

    public function apiLogin()
    {
        $curl = curl_init();
        //$name = Auth::user()->name;
        //$apiPass = "f1bf4faf87fb64b02f3354c49159e51e";

        curl_setopt_array($curl, array(
          CURLOPT_URL => "http://172.30.30.223:8006/api/user/Login",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => "{\n\"APIPassword\":\"f1bf4faf87fb64b02f3354c49159e51e\",\n\"MemberAccount\":\"misterkate\"\n}",
          CURLOPT_HTTPHEADER => array(
            "Accept: */*",
            "Cache-Control: no-cache",
            "Content-Type: application/json",
          ),
        ));

        $response = curl_exec($curl);
        $response = json_decode($response,true);

        $loginUrl = "http://172.30.30.223:8005/memberlogin.aspx?logincode=".$response['Message'];

        return view('launch_game')->with('loginUrl',$loginUrl);
    }
}
